document.addEventListener("DOMContentLoaded", function () {
    const scrollButtons = document.querySelectorAll(".scroll-button");
    
    scrollButtons.forEach(button => {
      button.addEventListener("click", (event) => {
        event.preventDefault(); // Evitar comportamiento por defecto del enlace
        
        const targetId = button.getAttribute("data-target");
        const targetSection = document.getElementById(targetId);
        if (targetSection) {
          window.scrollTo({
            top: targetSection.offsetTop,
            behavior: "smooth"
          });
        }
      });
    });
  });

